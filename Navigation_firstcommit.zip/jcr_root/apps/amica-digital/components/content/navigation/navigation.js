"use strict";
use(function () {

    var CONST_NODE_DEPTH_LIMIT = 2;//Ex: should be 4 for storm center in the path /content/amica/en/claim-center/storm-center

    var q1 = Number(granite.resource.properties["quantity1"]);
    var q2 = Number(granite.resource.properties["quantity2"]);
    var q3 = Number(granite.resource.properties["quantity3"]);
    var q4 = Number(granite.resource.properties["quantity4"]);

    var pagePath =  currentPage.getAbsoluteParent(CONST_NODE_DEPTH_LIMIT);

    var nodeDepth = currentPage.Depth;

    return { 
        quant1 : q1,
        quant2 : (q2 + q1),
        quant3 : (q3 + q2 + q1),
        quant4 : (q4 + q3 + q2 + q1),
        pagePath : pagePath,
        showLocalNav : (nodeDepth > CONST_NODE_DEPTH_LIMIT) 
    };
});

