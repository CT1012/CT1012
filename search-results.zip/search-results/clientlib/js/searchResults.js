/** searhResults NAMESPACE * */
searhResults = {};

searhResults.getQuickLinks= function(queryString) {

    if (queryString.length == 0) {

    } else {
        $.get("/bin/amica/searchServlet?q=" + queryString , function(data,
              status) {
            if (status == "success") {
                var searchGroupJSON = data;
                var source = $("#search-result-template").html();
                var template = Handlebars.compile(source);
                $(".search-result.dropdown-menu").html(template(searchGroupJSON));
                //searhResults.modifySearchResultsHeader(searchResultHeaderOutput);
            }
        });
    }
};


/*
searhResults.modifySearchResultsHeader= function(searchResultHeaderOutput) {

	var quicklinksCount = parseInt($( '.search-items').attr( "count" ));
	var searchResultsCount = parseInt($( '.searchResultCount').attr( "searchResultCount" ));

	if(quicklinksCount==="" || quicklinksCount==='undefined' || isNaN(quicklinksCount) ){
		quicklinksCount = 0;
    }

	if(searchResultsCount==="" || searchResultsCount==='undefined'|| isNaN(searchResultsCount)  ){
		searchResultsCount = 0;
    }

	var totalCount = quicklinksCount+searchResultsCount;

    content = 
        '<b>'+
        searchResultHeaderOutput.SearchResultCountZeroPart1 + " " + quicklinksCount + " " +searchResultHeaderOutput.SearchResultCountZeroPart2+
        '</b>';

	if(totalCount === 0){
    }else if (searchResultsCount === 0) {
		$('.searchResultsHeader').html(content);
	}else{
		$( '.searchResultCount').html(totalCount);
    }
};
*/