package com.amica.adc.amicacom.core.search;

public interface CoreSearch {

    Result getResult();

    String getQuery();

    long getHitsPerPage();

    String createCountURL(long count);
}
