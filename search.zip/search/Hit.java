package com.amica.adc.amicacom.core.search;

import javax.jcr.RepositoryException;

import org.apache.sling.api.resource.ValueMap;

public interface Hit {
    
    long getIndex() throws RepositoryException;

    String getIconClassPostfix() throws RepositoryException;

    String getURL() throws RepositoryException;

    String getExcerpt() throws RepositoryException;

    ValueMap getProperties() throws RepositoryException;

    String getTitle() throws RepositoryException;

    String getDescription() throws RepositoryException;

    String getExternalURL() throws RepositoryException;

}