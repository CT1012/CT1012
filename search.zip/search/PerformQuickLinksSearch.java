package com.amica.adc.amicacom.core.search;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Value;
import javax.jcr.ValueFormatException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;

public interface PerformQuickLinksSearch {

	JSONArray performSearch(String queryTerm,SlingHttpServletRequest request) throws RepositoryException, JSONException;
	Boolean checkKeywordExists(String keyword, String queryTerm);
	JSONArray getQuicklinkDataJSON(String keyword, Node linkNode) throws RepositoryException,JSONException;
	JSONArray addtoJsonResult(JSONArray jsonResults,JSONArray quicklinkMultiLinkResult) throws JSONException;
	JSONArray HandleResultSetIfOneLinkReturned(String quicklink,String keyword) throws JSONException;
	JSONArray HandleResultSetIfMultipleLinksReturned(Value[] quicklinks, String keyword ) throws JSONException, ValueFormatException, RepositoryException;
	
}
