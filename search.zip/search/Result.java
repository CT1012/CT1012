package com.amica.adc.amicacom.core.search;

import java.util.List;
import java.util.Map;

import javax.jcr.RepositoryException;

import com.amica.adc.amicacom.core.search.FilteredPageList;

public interface Result {

	List<Hit> getHits();

	long getExecutionTimeMillis();

	String getExecutionTime();

	long getTotalMatches();

	long getStartIndex();

	List<Page> getResultPages() throws RepositoryException;

	Page getNextPage() throws RepositoryException;

	Page getPreviousPage() throws RepositoryException;

	Page getCurrentPage() throws RepositoryException;

	FilteredPageList getFilteredPageList(int maxBeforeOrAfter) throws RepositoryException;

	String getSpellcheck();

}