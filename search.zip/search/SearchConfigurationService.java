package com.amica.adc.amicacom.core.search;

public interface SearchConfigurationService {

    public String getSearchQuicklinksAdminNodePath();

}