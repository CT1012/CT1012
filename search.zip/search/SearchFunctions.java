package com.amica.adc.amicacom.core.search;

import java.util.Locale;

import javax.jcr.RepositoryException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.jstl.core.Config;
import javax.servlet.jsp.jstl.fmt.LocalizationContext;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.scripting.SlingBindings;

import com.adobe.granite.xss.XSSAPI;


public final class SearchFunctions {
    
    private SearchFunctions() {}
    
    public static String createCountURL(CoreSearch search, long count) {
        return search.createCountURL(count);
    }
    
    public static FilteredPageList filteredPageList(SlingHttpServletRequest request, Result result, int maxBeforeOrAfter) throws RepositoryException {
        return result.getFilteredPageList(maxBeforeOrAfter);
    }    
    
    public static String encodeForHTML(XSSAPI xssApi, String string){
        return xssApi.encodeForHTML(string);
    }

    /**
     * Gets the value of the specified key from the ValueMap and either coerces
     * the value into the specified type or uses the specified type as a default
     * depending on the parameter passed in.
     * 
     * NOTE - copy of method from SlingFunctions as 5.6.1 does not include latest
     * Sling taglib
     * 
     * @param properties
     *            the ValueMap from which to retrieve the value
     * @param key
     *            the key for the value to retrieve
     * @param defaultOrType
     *            either the default value or the class to which to coerce the
     *            value
     * @return the value
     */
    @SuppressWarnings("unchecked")
    public static  <E> E getValue(ValueMap properties, String key, Object defaultOrType) {
        if (defaultOrType instanceof Class<?>) {
            return properties.get(key, (Class<E>) defaultOrType);
        } else {
            return properties.get(key, (E) defaultOrType);
        }
    }

}
