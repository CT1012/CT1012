package com.amica.adc.amicacom.core.search;


import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.api.resource.ValueMap;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
 
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import java.io.IOException;

import com.amica.adc.amicacom.core.search.impl.PerformQuickLinksSearchImpl;

import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Deactivate;

import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;

import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.jcr.api.SlingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import java.util.HashMap; 
import java.util.Map; 

import org.apache.sling.api.resource.ResourceResolver; 
import org.apache.sling.api.resource.Resource; 

@Component(service=Servlet.class,
property={
        Constants.SERVICE_DESCRIPTION + "=Search Servlet",
        "sling.servlet.methods=" + HttpConstants.METHOD_GET,
        "sling.servlet.paths="+ "/bin/amica/searchServlet"
})
public class SearchServlet extends SlingSafeMethodsServlet {

	@Reference
	private SlingRepository repository;

    @Reference
    private PerformQuickLinksSearch performQuickLinksSearch;

	private Session adminSession;
	
	private static final long serialVersionUID = 3169795937693969416L;
	private static final Logger log = LoggerFactory
			.getLogger(SearchServlet.class);

	protected void bindSlingRepository(SlingRepository paramSlingRepository) {
		this.repository = paramSlingRepository;
	}

	protected void unbindSlingRepository(SlingRepository paramSlingRepository) {
		if (this.repository == paramSlingRepository) {
			this.repository = null;
		}
	}
		
	@Override
	public final void doGet(final SlingHttpServletRequest request,
			final SlingHttpServletResponse response) throws ServletException,
			IOException {
		response.setHeader("Content-Type", "application/json");
		JSONObject jsonObject = new JSONObject();

        JSONObject jsonGroupResult;
		JSONArray jsonGroupArray = new JSONArray();
		JSONArray jsonResults;

		try {
			
			String queryTerm = request.getParameter("q");
			
			log.info("Search for Query Term : " + queryTerm);
			
			if (queryTerm != null) {
				
				jsonResults = performQuickLinksSearch.performSearch(queryTerm, request);
				
				log.info("Results found for Query Term : " + queryTerm + " are : "
						+ jsonResults.length());
				if (jsonResults.length() > 0) {
					jsonGroupResult = new JSONObject();
					jsonGroupResult.put("resultCount", jsonResults.length());
					jsonGroupResult.put("groupName", "Quick Links");
					jsonGroupResult.put("groupResult", jsonResults);
					jsonGroupArray.put(jsonGroupResult);
				}

				if (jsonGroupArray.length() > 0)
					jsonObject.put("searchResults", jsonGroupArray);
			}
		} catch (Exception e) {
			log.error("ERROR" + e + e.getStackTrace().toString());
			e.printStackTrace();
		}
		if (jsonObject.length() > 0)
			response.getWriter().print(jsonObject.toString());
		else
			response.getWriter().print("empty");
	}

	@Activate
	protected void activate() throws RepositoryException {
		log.info("Search Servlet Activated Successfully");
	}

	@Deactivate
	protected void deactivate() {
		log.info("Search Servlet Deactivated");
	}

}