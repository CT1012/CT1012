package com.amica.adc.amicacom.core.search.impl;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.jcr.query.RowIterator;

import org.apache.commons.lang3.StringUtils;
import org.apache.jackrabbit.commons.query.GQL;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;

import com.amica.adc.amicacom.core.search.CoreSearch;
import com.amica.adc.amicacom.core.search.Page;
import com.amica.adc.amicacom.core.search.Result;
import com.amica.adc.amicacom.core.search.SearchConstants;
import com.amica.adc.amicacom.core.search.impl.QueryParams;

import com.day.cq.commons.Externalizer;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.DamConstants;
import com.day.cq.search.Predicate;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.ResultPage;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.NameConstants;

public class CoreSearchImpl implements CoreSearch {

    private final ValueMap properties;

    private final Resource resource;

    private String queryString;

    private SlingHttpServletRequest request;

    private Session session;

    private SearchResult searchResult;

    private Result result;

    private List<Page> resultPages;

    private QueryParams query;

    private final QueryBuilder queryBuilder;

    private final Externalizer externalizer;

    private final String[] exclusionProperties;
    
    private CreateURL createURL;
    
    public CoreSearchImpl(QueryBuilder queryBuilder, Externalizer externalizer, String[] exclusionProperties,
            SlingHttpServletRequest request) {
        this.request = request;
        this.resource = request.getResource();
        this.session = request.getResourceResolver().adaptTo(Session.class);
        ValueMap props = resource.adaptTo(ValueMap.class);
        if (props == null) {
            this.properties = ValueMapDecorator.EMPTY;
        } else {
            this.properties = props;
        }
        this.query = new QueryParams(properties,exclusionProperties);
        this.queryBuilder = queryBuilder;
        this.externalizer = externalizer;
        this.exclusionProperties = exclusionProperties;
        init(request);
        
    }

    private void init(SlingHttpServletRequest request) {
        final boolean enableSynonyms = properties.get(SearchConstants.PROP_ENABLE_SYNONYMS, false);
        String charset = "ISO-8859-1"; // would be used by the GET requests

        if (request.getParameter(SearchConstants.CHARSET_PARAM_NAME) != null) {
            charset = request.getParameter(SearchConstants.CHARSET_PARAM_NAME);
        }

        if (request.getParameter(SearchConstants.QUERY_PARAM_NAME) != null) {
            try {
                addFulltext(new String(request.getParameter(SearchConstants.QUERY_PARAM_NAME).getBytes(charset), "UTF-8"),
                        enableSynonyms);
            } catch (UnsupportedEncodingException e) {
                // ignore
            }
        }
        if (request.getParameter(SearchConstants.START_PARAM_NAME) != null) {
            try {
                query.start = Long.parseLong(request.getParameter(SearchConstants.START_PARAM_NAME));
            } catch (NumberFormatException e) {
                // ignore
            }
        }

        if (request.getParameter(SearchConstants.COUNT_PARAM_NAME) != null) {
            try {
                addCount(Long.parseLong(request.getParameter(SearchConstants.COUNT_PARAM_NAME)));
            } catch (NumberFormatException e) {
                // ignore
            }
        }

        query.searchPaths = properties.get("searchIn", new String[0]);

    }

    private void addFulltext(String q, boolean enableSynonyms) {
        this.queryString = q;
        // use GQL to filter out wildcards
        try {
            final ParserCallback callback = new ParserCallback(enableSynonyms);
            GQL.parse(q, session, callback);
            query.parsedQuery = callback.getString();
        } catch (RepositoryException e) {
        }
    }
    
	@Override
    public String getQuery() {
        return queryString;
    }

    @Override
    public Result getResult() {
        if (!query.isValid()) {
            return null;
        }
        if (result == null) {
            PredicateGroup predicates = query.toPredicateGroup();
            Query q = queryBuilder.createQuery(predicates, session);
            searchResult = q.getResult();
            result = new ResultImpl(searchResult,request,queryString,externalizer,getHitsPerPage(),queryBuilder,query);
        }
        return result;
    }
    
    @Override
    public String createCountURL(long count) {
    	createURL=new CreateURL(request,queryString);
        return createURL.createNewURL(null, count);
    }
       
    @Override
    public long getHitsPerPage() {
        return query.count;
    }
    
    private void addCount(long count) {
        if (count <= SearchConstants.MAX_COUNT && count >= SearchConstants.MIN_COUNT) {
            query.count = count;
        }
    }
    
}
