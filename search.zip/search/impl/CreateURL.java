package com.amica.adc.amicacom.core.search.impl;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.apache.sling.api.SlingHttpServletRequest;

import com.amica.adc.amicacom.core.search.SearchConstants;
import com.day.cq.search.result.ResultPage;

public class CreateURL {
	
	ResultPage resultPage;
	long count;
	SlingHttpServletRequest request;
	String queryString;
	
	public CreateURL(SlingHttpServletRequest request, String queryString) {
		super();
		this.request = request;
		this.queryString = queryString;
	}


	public String createNewURL(ResultPage resultPage, long count) {
		this.resultPage = resultPage;
		this.count = count;
		
        StringBuffer url = new StringBuffer();
        url.append(request.getRequestURI());
        url.append("?").append(SearchConstants.QUERY_PARAM_NAME);
        url.append("=").append(encodeURL(queryString));
        if (resultPage != null) {
            url.append("&").append(SearchConstants.START_PARAM_NAME);
            url.append("=").append(resultPage.getStart());
        }
        if (count > 0) {
            url.append("&").append(SearchConstants.COUNT_PARAM_NAME);
            url.append("=").append(count);
        }

        return url.toString();
    }
	
    private static String encodeURL(String url) {
        try {
            return URLEncoder.encode(url, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            // will never happen
            return url;
        }
    }
}
