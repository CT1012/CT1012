package com.amica.adc.amicacom.core.search.impl;

import org.apache.sling.api.SlingHttpServletRequest;

import com.amica.adc.amicacom.core.search.Page;
import com.day.cq.search.result.ResultPage;

/**
 * A result basepage.
 */
final class PageImpl implements Page {

    /**
     * The underlying CQ result basepage.
     */
    private final ResultPage rp;
    private CreateURL createURL;
    private SlingHttpServletRequest request;
    private String queryString;
    private Long queryHitsPerPage;

    /**
     * Creates a new basepage with the given CQ result basepage.
     * 
     * @param rp
     *            the CQ result basepage.
     */
    PageImpl(ResultPage rp, SlingHttpServletRequest request, String queryString, Long queryHitsPerPage) {
        this.rp = rp;
        this.queryString = queryString;
        this.queryHitsPerPage = queryHitsPerPage;
        this.request = request;
    }

    /**
     * @return zero based index of this result basepage.
     */
    @Override
    public long getIndex() {
        return rp.getIndex();
    }

    /**
     * @return the URL to this search result basepage.
     */
    @Override
    public String getURL() {
    	createURL = new CreateURL(request,queryString);
        return createURL.createNewURL(rp, queryHitsPerPage);
    }

    /**
     * @return whether this basepage is currently displayed.
     */
    @Override
    public boolean isCurrentPage() {
        return rp.isCurrentPage();
    }
}

