package com.amica.adc.amicacom.core.search.impl;

import javax.jcr.RepositoryException;

import org.apache.jackrabbit.commons.query.GQL;

class ParserCallback implements GQL.ParserCallback {

    private final StringBuilder builder;
    private final boolean synonymsEnabled;

    public ParserCallback(final boolean synonymsEnabled) {
        this.builder = new StringBuilder();
        this.synonymsEnabled = synonymsEnabled;
    }

    public String getString() {
        return builder.toString().trim();
    }

    @Override
    public void term(String property, String value, boolean optional) throws RepositoryException {
        builder.append(" ");
        if (optional) {
            builder.append("OR ");
        }
        if (property.length() > 0) {
            builder.append(property).append(":");
        }
        if (synonymsEnabled) {
            builder.append("~");
        }
        builder.append(value);
    }

}
