package com.amica.adc.amicacom.core.search.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ValueMap;

import com.day.cq.search.Predicate;
import com.day.cq.search.PredicateGroup;

final class QueryParams {

    private static final String PROP_DEFAULT_COUNT = "defaultCount";

    private static final int DEFAULT_COUNT = 10;
    
    private final ValueMap properties;
    
    String parsedQuery = "";
    long start;
    long count;
    String[] searchPaths;
    
    private final String[] exclusionProperties;
    
    public QueryParams(ValueMap properties , String[] exclusionProperties) {
		super();
		this.properties = properties;
		count = properties.get(PROP_DEFAULT_COUNT, DEFAULT_COUNT);
		this.exclusionProperties = exclusionProperties;
	}

	public Map<String, String> buildInitialMap(String fulltext) {
        Map<String, String> map = new HashMap<String, String>();

        map.put("1_group.p.or", "true");
        map.put("1_group.1_type", "cq:Page");
        map.put("1_group.2_type", "dam:Asset");

        if (searchPaths.length >= 1) {
            map.put("2_group.p.or", "true");
            for (int i = 0; i < searchPaths.length; i++) {
                map.put(String.format("2_group.%s_path", i + 1), searchPaths[i]);
            }
        }

        map.put("p.limit", Long.toString(count));
        map.put("p.offset", Long.toString(start));

        //map.put("fulltext", fulltext);
        map.put("3_group.p.or", "true");
        map.put("3_group.1_fulltext", fulltext);
        map.put("3_group.1_fulltext.relPath", ".");
        map.put("3_group.2_fulltext", fulltext + "^2");
        map.put("3_group.2_fulltext.relPath", "jcr:content/@jcr:title");
        map.put("3_group.3_fulltext", fulltext + "^4");
        map.put("3_group.3_fulltext.relPath", "jcr:content/@jcr:description");
        map.put("3_group.4_fulltext", fulltext + "^6");
        map.put("3_group.4_fulltext.relPath", "jcr:content/@cq:tags");

        // Commented below to resolve the asset hide issue mentioned in DE200 (Rally)
        /*
        for (int i = 0; i < exclusionProperties.length; i++) {
            String propName = ""+i+"_boolproperty";
            map.put(propName, exclusionProperties[i]);
            map.put(propName + ".value", "false");
            
        }
        */
        
        // Ignoring the exclusionProperties which is set in OSGI config - Below is the replacement code for the above commented code
        map.put("4_group.p.or", "true");
        map.put("4_group.1_group.type", "cq:Page");
        map.put("4_group.1_group.1_boolproperty", "jcr:content/@hideInSearch");
        map.put("4_group.1_group.1_boolproperty.value", "false");
        map.put("4_group.2_group.type", "dam:Asset");
        map.put("4_group.2_group.2_boolproperty", "jcr:content/metadata/@hideInSearch");
        map.put("4_group.2_group.2_boolproperty.value", "false");

        map.put(Predicate.ORDER_BY, "@jcr:score");
        map.put(Predicate.ORDER_BY + "." + Predicate.PARAM_SORT, Predicate.SORT_DESCENDING);

        return map;
    }

    public PredicateGroup toPredicateGroup() {
        Map<String, String> map = buildInitialMap(parsedQuery);
        
//        int nextGroupIndex = 3;
//
//        for (Resource facetResource : facetResources) {
//            String resourceName = facetResource.getName();
//            int facetIndex = 1;
//            ValueMap props = facetResource.adaptTo(ValueMap.class);
//            String predicateName = props.get("predicateName", "property");
//            String[] properties = props.get("properties", new String[0]);
//            List<String> predicateNames = new ArrayList<String>(properties.length);
//
//            map.put(String.format("%s_group.p.or", nextGroupIndex), "true");
//
//            for (String propertyName : properties) {
//                String basefacetName = String.format("%s_group.%s_%s", nextGroupIndex, facetIndex,
//                        predicateName);
//                map.put(basefacetName + ".property", propertyName);
//                predicateNames.add(basefacetName);
//
//                if (resourceName.equals(selectedFacet) && selectedFacetValue != null) {
//                    map.put(basefacetName + ".1_value", selectedFacetValue);
//                }
//
//                facetIndex++;
//            }
//            facetPredicates.put(facetResource.getName(), predicateNames);
//            nextGroupIndex++;
//        }
        return PredicateGroup.create(map);
    }

    public boolean isValid() {
        return StringUtils.isNotBlank(parsedQuery);
    }

}