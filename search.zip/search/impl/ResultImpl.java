package com.amica.adc.amicacom.core.search.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;

import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.jcr.query.RowIterator;

import org.apache.sling.api.SlingHttpServletRequest;

import com.amica.adc.amicacom.core.search.FilteredPageList;
import com.amica.adc.amicacom.core.search.Hit;
import com.amica.adc.amicacom.core.search.Page;
import com.amica.adc.amicacom.core.search.Result;
import com.day.cq.commons.Externalizer;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.ResultPage;
import com.day.cq.search.result.SearchResult;

final class ResultImpl implements Result {

    /**
     * The underyling CQ search result instance.
     */
    private final SearchResult result;

    /**
     * The hits on the current result basepage.
     */
    private final List<Hit> hits;

    /**
     * The spell suggestion. Set only when requested. An empty string indicates that a suggestion was returned by
     * the spellcheck, but does not return results for the current query. See {@link #getSpellcheck()}.
     */
    private String spellSuggestion;
    
    private List<Page> resultPages;
    
    private SlingHttpServletRequest request;
    
    private String queryString;
    
    private Long queryHitsPerPage;
    
    private QueryBuilder queryBuilder;
    
    private QueryParams queryParams;
    
    private static final String SPELLCHECK_QUERY = "/jcr:root[rep:spellcheck('${query}')]/(rep:spellcheck())";
     /**
     * Creates a new result based on the given CQ search result.
     * 
     * @param result
     *            the CQ search result.
     */
    ResultImpl(SearchResult result, SlingHttpServletRequest request, String queryString, Externalizer externalizer, Long queryHitsPerPage , QueryBuilder queryBuilder, QueryParams queryParams) {
        this.result = result;
        this.hits = new ArrayList<Hit>();
        this.queryString = queryString;
        this.queryHitsPerPage = queryHitsPerPage;
        this.request = request;
        this.queryBuilder=queryBuilder;
        this.queryParams=queryParams;
        
        for (com.day.cq.search.result.Hit h : result.getHits()) {
            this.hits.add(new HitImpl(h,request,externalizer));
        }
        
    }

    /**
     * Returns the execution time in fractions of a second. <br/>
     * Example: 0.08 (means, the query took 80 milliseconds to execute).
     * 
     * @return the execution time of the query.
     */
    @Override
    public String getExecutionTime() {
        return result.getExecutionTime();
    }

    /**
     * Returns the execution time in milliseconds.
     * 
     * @return the execution time of the query.
     */
    @Override
    public long getExecutionTimeMillis() {
        return result.getExecutionTimeMillis();
    }


    /**
     * @return a List of {@link Hit}s to display on the result basepage.
     */
    @Override
    public List<Hit> getHits() {
        return hits;
    }

    /**
     * @return the basepage, which contains the information about the next basepage. Returns <code>null</code> if there is
     *         no next basepage (i.e. the current basepage is the last basepage).
     * @throws javax.jcr.RepositoryException
     *             if an error occurs while reading from the query result.
     */
    @Override
    public Page getNextPage() throws RepositoryException {
        ResultPage next = result.getNextPage();
        if (next != null) {
            return new PageImpl(next,request,queryString,queryHitsPerPage);
        } else {
            return null;
        }
    }

    @Override
    public Page getCurrentPage() throws RepositoryException {
        for (Page page : getResultPages()) {
            if (page.isCurrentPage()) {
                return page;
            }
        }
        return null;
    }

    /**
     * @return the basepage, which contains the information about the previous basepage. Returns <code>null</code> if there
     *         is no previous basepage (i.e. the current basepage is the first basepage).
     * @throws javax.jcr.RepositoryException
     *             if an error occurs while reading from the query result.
     */
    @Override
    public Page getPreviousPage() throws RepositoryException {
        ResultPage previous = result.getPreviousPage();
        if (previous != null) {
            return new PageImpl(previous,request,queryString,queryHitsPerPage);
        } else {
            return null;
        }
    }

    /**
     * @return a List of {@link com.test.search.impl.CoreSearchImpl.PageImpl}es to display the navigation through the result pages.
     * @throws javax.jcr.RepositoryException
     *             if an error occurs while reading from the query result.
     */
    @Override
    public List<Page> getResultPages() throws RepositoryException {
        if (resultPages == null) {
            resultPages = new ArrayList<Page>();
            for (ResultPage rp : result.getResultPages()) {
                resultPages.add(new PageImpl(rp,request,queryString,queryHitsPerPage));
            }
        }
        return resultPages;
    }

    /**
     * @return the start index. i.e. from where to start to display the hits.
     */
    @Override
    public long getStartIndex() {
        return result.getStartIndex();
    }

    /**
     * @return the total number of matches.
     */
    @Override
    public long getTotalMatches() {
        return result.getTotalMatches();
    }
    
    @Override
    public FilteredPageList getFilteredPageList(int maxBeforeOrAfter) throws RepositoryException {
        List<Page> pages = getResultPages();
        if (maxBeforeOrAfter < 0) {
            return new FilteredPageListImpl(pages, false, false);
        }
        Page currentPage = getCurrentPage();

        long currentIndex = currentPage.getIndex();
        long minIndex = currentIndex - maxBeforeOrAfter;
        long maxIndex = currentIndex + maxBeforeOrAfter;
        if (minIndex < 0) {
            minIndex = 0;
            maxIndex = maxBeforeOrAfter * 2;
        } else {
            int numPages = pages.size();
            if (maxIndex >= numPages) {
                maxIndex = numPages;
                minIndex = numPages - (maxBeforeOrAfter * 2) - 1;
            }
        }

        boolean hiddenBefore = false;
        ;
        boolean hiddenAfter = false;
        ;
        List<Page> copy = new ArrayList<Page>(pages);
        Iterator<Page> iterator = copy.iterator();
        while (iterator.hasNext()) {
            Page page = iterator.next();
            long index = page.getIndex();
            if (index < minIndex) {
                iterator.remove();
                hiddenBefore = true;
            } else if (index > maxIndex) {
                iterator.remove();
                hiddenAfter = true;
            }
        }

        return new FilteredPageListImpl(copy, hiddenBefore, hiddenAfter);
    }
    
    /**
     * @return the result of a spell check or <code>null</code> if spell checking is not supported or the repository
     *         thinks the spelling is correct.
     */
    @Override
    public String getSpellcheck() {
        if (spellSuggestion == null) {
            try {
                Session session = request.getResourceResolver().adaptTo(Session.class);
                @SuppressWarnings("deprecation")
                RowIterator rows = session
                        .getWorkspace()
                        .getQueryManager()
                        .createQuery(
                                SPELLCHECK_QUERY.replaceAll("\\$\\{query\\}",
                                        Matcher.quoteReplacement(queryString)), javax.jcr.query.Query.XPATH)
                        .execute().getRows();
                String suggestion = null;
                if (rows.hasNext()) {
                    Value v = rows.nextRow().getValue("rep:spellcheck()");
                    if (v != null) {
                        suggestion = v.getString();
                    }
                }
                if (suggestion == null) {
                    return null;
                }

                // set query term to suggestion and run query again
                if (checkSuggestion(suggestion)) {
                    spellSuggestion = suggestion;
                } else {
                    spellSuggestion = "";
                }
            } catch (RepositoryException e) {
                spellSuggestion = "";
            }
        }
        if (spellSuggestion.length() == 0) {
            return null;
        } else {
            return spellSuggestion;
        }
    }
    
    private boolean checkSuggestion(String suggestion) {

    	Session session = request.getResourceResolver().adaptTo(Session.class);
        Map<String, String> suggestionQuery = queryParams.buildInitialMap(suggestion);
        PredicateGroup predicates = PredicateGroup.create(suggestionQuery);
        Query query = queryBuilder.createQuery(predicates, session);
        return query.getResult().getTotalMatches() > 0;
    }
}

