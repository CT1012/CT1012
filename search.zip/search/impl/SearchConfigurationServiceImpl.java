package com.amica.adc.amicacom.core.search.impl;

import org.apache.felix.scr.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amica.adc.amicacom.core.search.SearchConfigurationService;

import org.osgi.service.component.ComponentContext;


@Component(
        metatype = true,
        immediate = true,
        label = "Amica Search Services Configuration",
        description = "Configuration point for Amica Search Services Integration"
        )
@Service(value = SearchConfigurationService.class)
@Properties(value = {
    @Property(name = "service.description", value = "Configuration point for Amica Search Services Integration")})

public class SearchConfigurationServiceImpl implements SearchConfigurationService {

    private static final Logger logger = LoggerFactory.getLogger(SearchConfigurationServiceImpl.class);
    
    @Property(label = "Search Quicklinks Admin Node Path", description = "The node path for the search quicklinks admin.", propertyPrivate = false, value = "/etc/amica/searchquicklinks/jcr:content/list")
	private static final String QL_ADMIN_NODE_PATH = "amica.search.quicklinks.adminnodepath";
	   
    
    private String searchQuicklinksAdminNodePath;
    
    @Activate
    @Modified
    protected void activate(ComponentContext ctx) {

         if( ctx.getProperties().get( QL_ADMIN_NODE_PATH ) != null ){
            searchQuicklinksAdminNodePath = (String) ctx.getProperties().get( QL_ADMIN_NODE_PATH );
            logger.info( "Search Quicklinks Node Path {}", searchQuicklinksAdminNodePath );
        }
    }
	
    @Override
    public String getSearchQuicklinksAdminNodePath() {
        return searchQuicklinksAdminNodePath;
    }

}